Weather Color
=============

Designer: Yun Liu (https://www.iconfinder.com/Neolau1119)
License: Free for commercial use (Include link to authors website)
